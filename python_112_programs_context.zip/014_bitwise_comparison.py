print("Program: Bitwise Comparison")

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
print(a & b)
print(a | b)
print(a ^ b)
